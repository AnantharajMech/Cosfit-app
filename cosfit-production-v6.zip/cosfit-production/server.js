'use strict';
require('dotenv').config();

const express    = require('express');
const Database   = require('better-sqlite3');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const rateLimit  = require('express-rate-limit');
const helmet     = require('helmet');
const cors       = require('cors');
const compression = require('compression');
const morgan     = require('morgan');
const path       = require('path');
const crypto     = require('crypto');
const { body, validationResult } = require('express-validator');

// ════════════════════════════════════════════════════════════════
// ENVIRONMENT CONFIG
// ════════════════════════════════════════════════════════════════
const PORT       = process.env.PORT || 3000;
const NODE_ENV   = process.env.NODE_ENV || 'development';
const IS_PROD    = NODE_ENV === 'production';
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
const JWT_EXP    = process.env.JWT_EXPIRES_IN || '7d';
const ADM_EXP    = process.env.ADMIN_JWT_EXPIRES_IN || '12h';
const GMAIL_USER = process.env.GMAIL_USER || '';
const GMAIL_PASS = process.env.GMAIL_APP_PASSWORD || '';
const DB_PATH    = process.env.DB_PATH || './cosfit.db';
const ALLOWED    = process.env.ALLOWED_ORIGIN || '*';

// ════════════════════════════════════════════════════════════════
// DATABASE INITIALISATION
// ════════════════════════════════════════════════════════════════
const db = new Database(DB_PATH, { verbose: IS_PROD ? null : undefined });
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT NOT NULL,
    username         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email            TEXT NOT NULL UNIQUE COLLATE NOCASE,
    phone            TEXT NOT NULL,
    password         TEXT NOT NULL,
    avatar           TEXT DEFAULT '😊',
    plan             TEXT,
    plan_name        TEXT,
    plan_activated_at TEXT,
    goal             TEXT DEFAULT 'general',
    pref             TEXT DEFAULT 'all',
    age              TEXT,
    weight           TEXT,
    height           TEXT,
    gender           TEXT DEFAULT 'm',
    address          TEXT DEFAULT '',
    joined_at        TEXT NOT NULL,
    last_login       TEXT,
    is_active        INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS admins (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    role      TEXT NOT NULL,
    username  TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password  TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS otps (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    identifier TEXT NOT NULL COLLATE NOCASE,
    code       TEXT NOT NULL,
    type       TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    used       INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS orders (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id),
    user_name      TEXT NOT NULL,
    user_username  TEXT,
    user_phone     TEXT,
    user_address   TEXT,
    items          TEXT NOT NULL,
    subtotal       REAL NOT NULL,
    delivery       REAL NOT NULL DEFAULT 0,
    gst            REAL NOT NULL DEFAULT 0,
    platform_fee   REAL NOT NULL DEFAULT 0,
    total          REAL NOT NULL,
    status_idx     INTEGER NOT NULL DEFAULT 0,
    payment_status TEXT NOT NULL DEFAULT 'Cash on Delivery',
    created_at     INTEGER NOT NULL,
    updated_at     INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS menu_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    goal        TEXT NOT NULL,
    meal        TEXT NOT NULL,
    name        TEXT NOT NULL,
    description TEXT,
    calories    INTEGER DEFAULT 0,
    protein     REAL DEFAULT 0,
    carbs       REAL DEFAULT 0,
    fat         REAL DEFAULT 0,
    price       REAL NOT NULL,
    emoji       TEXT DEFAULT '🍱',
    tag         TEXT,
    prep_time   TEXT DEFAULT '15m',
    is_active   INTEGER NOT NULL DEFAULT 1,
    in_stock    INTEGER NOT NULL DEFAULT 1,
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS plans (
    id         TEXT PRIMARY KEY,
    label      TEXT NOT NULL,
    price      REAL NOT NULL,
    period     TEXT NOT NULL,
    save_badge TEXT,
    is_popular INTEGER NOT NULL DEFAULT 0,
    color      TEXT DEFAULT '#4ade80',
    features   TEXT NOT NULL DEFAULT '[]',
    is_active  INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS plan_activations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    user_name    TEXT NOT NULL,
    user_username TEXT,
    user_phone   TEXT,
    plan_id      TEXT NOT NULL,
    plan_name    TEXT NOT NULL,
    plan_price   REAL NOT NULL,
    plan_per     TEXT NOT NULL,
    activated_at TEXT NOT NULL,
    payment_status TEXT NOT NULL DEFAULT 'Paid',
    is_active    INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    icon       TEXT,
    label      TEXT NOT NULL,
    message    TEXT NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_orders_user    ON orders(user_id);
  CREATE INDEX IF NOT EXISTS idx_orders_status  ON orders(status_idx, created_at);
  CREATE INDEX IF NOT EXISTS idx_menu_goal_meal ON menu_items(goal, meal);
  CREATE INDEX IF NOT EXISTS idx_otps_ident     ON otps(identifier, type);
  CREATE INDEX IF NOT EXISTS idx_notifs_user    ON notifications(user_id, is_read);
`);

// ════════════════════════════════════════════════════════════════
// SEED DATA (runs only on first start)
// ════════════════════════════════════════════════════════════════
const seedAll = db.transaction(() => {
  // Admin accounts — hashed on first seed
  const adminsData = [
    { id:1, name:'Anantharaje Einstein', role:'Super Admin', username:'Anantharajmech', raw:'ananthaarthi160893' },
    { id:2, name:'Aarthi',               role:'Manager',     username:'Aarthimech',     raw:'aarthiananth160893' },
    { id:3, name:'Ajith',                role:'Staff',        username:'Ajithmech',      raw:'ajithmerga160893'  },
  ];
  const insAdmin = db.prepare('INSERT OR IGNORE INTO admins (id,name,role,username,password,is_active) VALUES (?,?,?,?,?,1)');
  for (const a of adminsData) insAdmin.run(a.id, a.name, a.role, a.username, bcrypt.hashSync(a.raw, 12));

  // Default settings
  const defaults = {
    delivery_charge:'40', free_delivery_min:'400', platform_fee:'10', gst:'5',
    app_name:'Cosfit', tagline:'Eat Smart · Live Strong', currency:'₹',
    support_phone:'8778148899', support_email:'anantharajeinstein@gmail.com',
  };
  const insSetting = db.prepare('INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)');
  for (const [k,v] of Object.entries(defaults)) insSetting.run(k,v);

  // Plans
  const plansData = [
    { id:'w', label:'Weekly',  price:499,  period:'week',  save_badge:null,        is_popular:0, color:'#60a5fa', features:['Personalized meal plan','Calorie & macro tracking','Free delivery on all orders','Priority customer support','Daily health tips'] },
    { id:'m', label:'Monthly', price:1499, period:'month', save_badge:'Save 25%',  is_popular:1, color:'#4ade80', features:['Everything in Weekly','Advanced nutrition analytics','Chef special exclusive items','Dedicated health coach','Weekly progress reports','Meal prep guidance'] },
    { id:'y', label:'Yearly',  price:9999, period:'year',  save_badge:'Save 58%',  is_popular:0, color:'#fbbf24', features:['Everything in Monthly','Annual health assessment','Exclusive premium recipes','Family plan for 4 members','Priority chef requests','Premium VIP badge','Yearly health report'] },
  ];
  const insPlan = db.prepare('INSERT OR IGNORE INTO plans (id,label,price,period,save_badge,is_popular,color,features) VALUES (?,?,?,?,?,?,?,?)');
  for (const p of plansData) insPlan.run(p.id,p.label,p.price,p.period,p.save_badge,p.is_popular,p.color,JSON.stringify(p.features));

  // Menu items (only if empty)
  const menuCount = db.prepare('SELECT COUNT(*) as c FROM menu_items').get().c;
  if (menuCount === 0) {
    const now = Date.now();
    const insMenu = db.prepare('INSERT INTO menu_items (goal,meal,name,description,calories,protein,carbs,fat,price,emoji,tag,prep_time,is_active,in_stock,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,1,?,?)');
    const M = [
      // WEIGHT LOSS
      ['weight_loss','breakfast','Green Detox Smoothie','Spinach, apple, ginger, lemon',185,5,32,3,129,'🥤','Detox','5m'],
      ['weight_loss','breakfast','Oats Berry Bowl','Rolled oats, mixed berries, chia seeds',240,9,38,5,149,'🥣','High Fiber','8m'],
      ['weight_loss','breakfast','Egg White Wrap','3 egg whites, spinach, whole grain',210,22,18,4,169,'🌯','Protein','10m'],
      ['weight_loss','breakfast','Watermelon Mint Juice','Fresh watermelon, mint, lime',90,1,22,0,89,'🍉','Low Cal','3m'],
      ['weight_loss','lunch','Grilled Chicken Salad','Lettuce, tomato, cucumber, lemon dressing',320,34,12,11,229,'🥗','Low Carb','15m'],
      ['weight_loss','lunch','Millet Khichdi','Foxtail millet, moong dal, turmeric',290,13,48,5,179,'🍲','Gluten Free','18m'],
      ['weight_loss','lunch','Tuna Quinoa Bowl','Quinoa, tuna, avocado, cherry tomato',380,36,28,12,279,'🥙','Omega-3','12m'],
      ['weight_loss','dinner','Steamed Fish & Greens','Tilapia, broccoli, beans, lemon',310,38,10,12,259,'🐟','Heart Healthy','20m'],
      ['weight_loss','dinner','Moong Dal Soup','Green lentil, ginger, pepper, coriander',195,13,28,3,139,'🍵','Digestive','15m'],
      ['weight_loss','dinner','Zucchini Noodles','Zucchini, cherry tomato, basil pesto',225,8,20,11,199,'🍝','Low Carb','12m'],
      // MUSCLE GAIN
      ['muscle_gain','breakfast','Protein Power Bowl','4 eggs, oats, banana, peanut butter',620,42,58,18,219,'💪','Muscle Fuel','12m'],
      ['muscle_gain','breakfast','Chicken Omelette','Chicken strips, 3 eggs, cheese, peppers',540,48,8,22,239,'🍳','High Protein','12m'],
      ['muscle_gain','breakfast','Mass Gainer Shake','Milk, banana, oats, whey, almond butter',780,55,80,20,249,'🥛','Mass Builder','5m'],
      ['muscle_gain','lunch','Chicken Quinoa Feast','250g grilled chicken, quinoa, broccoli',680,56,55,16,329,'🍗','Muscle Gain','20m'],
      ['muscle_gain','lunch','Paneer Power Thali','Paneer tikka, brown rice, dal, salad',720,44,72,24,299,'🧀','Vegetarian','22m'],
      ['muscle_gain','lunch','Salmon Rice Bowl','Grilled salmon, jasmine rice, edamame',660,52,60,18,349,'🍣','Omega-3','18m'],
      ['muscle_gain','dinner','Steak & Sweet Potato','Lean beef steak, sweet potato mash',690,54,48,22,389,'🥩','Iron Rich','25m'],
      ['muscle_gain','dinner','Tuna Pasta Bake','Whole wheat pasta, tuna, tomato sauce',610,46,65,12,269,'🍝','High Protein','20m'],
      ['muscle_gain','dinner','Egg Bhurji & Roti','Scrambled eggs, 2 whole wheat rotis',520,38,42,18,189,'🥚','Classic','15m'],
      // GENERAL
      ['general','breakfast','Avocado Toast','Multigrain bread, avocado, seeds, lemon',310,10,34,16,179,'🥑','Healthy Fat','8m'],
      ['general','breakfast','Idli Sambar','3 idlis, sambar, coconut chutney',280,9,52,3,119,'🫕','Traditional','10m'],
      ['general','breakfast','Masala Dosa','Crispy dosa, potato masala, chutneys',370,8,62,10,149,'🫓','Traditional','15m'],
      ['general','breakfast','Banana Walnut Smoothie','Banana, walnut, dates, almond milk',340,8,48,12,149,'🍌','Energy','5m'],
      ['general','lunch','Dal Tadka & Brown Rice','Yellow dal, ghee, brown rice, pickle',440,18,72,8,159,'🍚','Classic','18m'],
      ['general','lunch','Chicken Biryani Bowl','Basmati rice, chicken, saffron, raita',520,32,62,14,249,'🍛','Flavourful','25m'],
      ['general','lunch','Veggie Buddha Bowl','Roasted veg, chickpeas, tahini, greens',420,16,58,14,219,'🥗','Plant Based','15m'],
      ['general','lunch','Rajma Chawal','Red kidney beans, white rice, salad',480,20,78,8,149,'🫘','Protein Rich','20m'],
      ['general','dinner','Palak Paneer & Roti','Spinach gravy, cottage cheese, 2 rotis',390,22,44,14,189,'🥬','Iron Rich','20m'],
      ['general','dinner','Grilled Veg Platter','Mixed grilled veg, hummus, pita bread',320,12,48,8,199,'🫕','Light','15m'],
      ['general','dinner','Fish Curry & Rice','Tilapia fish curry, steamed basmati rice',430,36,52,10,229,'🐠','Omega-3','22m'],
    ];
    for (const m of M) insMenu.run(...m, now, now);
  }
});
seedAll();

// ════════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════════
const genOTP      = () => String(Math.floor(100000 + Math.random() * 900000));
const mkToken     = (payload, exp) => jwt.sign(payload, JWT_SECRET, { expiresIn: exp });
const chkToken    = (token) => jwt.verify(token, JWT_SECRET);
const validate    = (req, res, next) => { const e = validationResult(req); if (!e.isEmpty()) return res.status(400).json({ error: e.array()[0].msg }); next(); };
const getSettings = () => db.prepare('SELECT key, value FROM settings').all().reduce((o,r) => ({...o,[r.key]:r.value}), {});

const storeOTP = (identifier, code, type) => {
  db.prepare('DELETE FROM otps WHERE identifier=? AND type=?').run(identifier.toLowerCase(), type);
  db.prepare('INSERT INTO otps (identifier,code,type,expires_at,created_at) VALUES (?,?,?,?,?)')
    .run(identifier.toLowerCase(), code, type, Date.now() + 10*60*1000, Date.now());
};

const checkOTP = (identifier, code, type) => {
  const r = db.prepare('SELECT * FROM otps WHERE identifier=? AND type=? AND used=0 ORDER BY created_at DESC LIMIT 1')
    .get(identifier.toLowerCase(), type);
  if (!r)             return { ok:false, msg:'OTP not found. Please request a new one.' };
  if (Date.now()>r.expires_at) return { ok:false, msg:'OTP has expired. Please request a new one.' };
  if (r.code !== code) return { ok:false, msg:'Wrong OTP. Please check and try again.' };
  db.prepare('UPDATE otps SET used=1 WHERE id=?').run(r.id);
  return { ok:true };
};

const sendEmail = async (to, subject, html) => {
  if (!GMAIL_USER || !GMAIL_PASS) {
    console.log(`\n📧 [MOCK EMAIL] To: ${to}\n   Subject: ${subject}\n   (Configure GMAIL_USER & GMAIL_APP_PASSWORD to send real emails)\n`);
    return false;
  }
  const t = nodemailer.createTransport({ service:'gmail', auth:{ user:GMAIL_USER, pass:GMAIL_PASS } });
  await t.sendMail({ from:`Cosfit 🥗 <${GMAIL_USER}>`, to, subject, html });
  return true;
};

const emailOTPHtml = (name, otp, purpose='Reset') => `
<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;background:#f5f5f5;border-radius:16px;overflow:hidden">
  <div style="background:linear-gradient(135deg,#4ade80,#22c55e);padding:28px 32px">
    <h1 style="color:#fff;margin:0;font-size:28px;font-weight:900">🥗 Cosfit</h1>
    <p style="color:rgba(255,255,255,.85);margin:6px 0 0;font-size:14px">Eat Smart · Live Strong</p>
  </div>
  <div style="padding:32px;background:#fff">
    <h2 style="color:#060c08;font-size:20px;margin:0 0 12px">Password ${purpose} OTP</h2>
    <p style="color:#555;line-height:1.6">Hi <strong>${name}</strong>,</p>
    <p style="color:#555;line-height:1.6">Here is your One-Time Password (OTP):</p>
    <div style="background:#060c08;border-radius:14px;padding:28px;text-align:center;margin:24px 0">
      <span style="color:#4ade80;font-size:40px;font-weight:900;letter-spacing:10px">${otp}</span>
    </div>
    <p style="color:#777;font-size:13px">⏱ Valid for <strong>10 minutes</strong>. Do not share this OTP with anyone.</p>
    <p style="color:#999;font-size:12px;margin-top:24px">If you didn't request this, please ignore this email. Your account is safe.</p>
    <hr style="border:none;border-top:1px solid #eee;margin:24px 0"/>
    <p style="color:#bbb;font-size:11px;text-align:center">© 2024 Cosfit · Coscoom Creative Tech Solutions</p>
  </div>
</div>`;

const menuToFoods = (rows) => {
  const out = {
    weight_loss:{ breakfast:[], lunch:[], dinner:[] },
    muscle_gain:{ breakfast:[], lunch:[], dinner:[] },
    general:    { breakfast:[], lunch:[], dinner:[] },
  };
  for (const r of rows) {
    if (out[r.goal]?.[r.meal]) out[r.goal][r.meal].push({
      id:r.id, name:r.name, desc:r.description, cal:r.calories,
      p:r.protein, c:r.carbs, f:r.fat, price:r.price,
      emoji:r.emoji, tag:r.tag, time:r.prep_time,
      active:!!r.is_active, stock:!!r.in_stock,
    });
  }
  return out;
};

const safeUser = (u) => {
  if (!u) return null;
  const { password, ...rest } = u;
  return rest;
};

// ════════════════════════════════════════════════════════════════
// EXPRESS APP
// ════════════════════════════════════════════════════════════════
const app = express();

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors({ origin: IS_PROD ? ALLOWED : '*', credentials: true }));
app.use(compression());
app.use(morgan(IS_PROD ? 'combined' : 'dev'));
app.use(express.json({ limit:'10mb' }));
app.use(express.urlencoded({ extended:true }));
app.use(express.static(path.join(__dirname, 'public')));

// ── Rate Limiters ───────────────────────────────────────────
const authLim = rateLimit({ windowMs:15*60*1000, max:10, message:{ error:'Too many attempts. Try again in 15 minutes.' }, standardHeaders:true, legacyHeaders:false });
const otpLim  = rateLimit({ windowMs:60*1000,    max:3,  message:{ error:'Too many OTP requests. Wait 1 minute.' } });
const apiLim  = rateLimit({ windowMs:60*1000,    max:120, message:{ error:'Too many requests.' } });
app.use('/api/', apiLim);

// ── Auth Middleware ─────────────────────────────────────────
const requireUser = (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ','');
    if (!token) return res.status(401).json({ error:'Authentication required' });
    const dec = chkToken(token);
    if (dec.type !== 'user') return res.status(401).json({ error:'Invalid token' });
    const u = db.prepare('SELECT * FROM users WHERE id=? AND is_active=1').get(dec.id);
    if (!u) return res.status(401).json({ error:'Account not found or disabled' });
    req.user = u; next();
  } catch { res.status(401).json({ error:'Invalid or expired token. Please sign in again.' }); }
};

const requireAdmin = (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ','');
    if (!token) return res.status(401).json({ error:'Admin authentication required' });
    const dec = chkToken(token);
    if (dec.type !== 'admin') return res.status(403).json({ error:'Admin access required' });
    const a = db.prepare('SELECT * FROM admins WHERE id=? AND is_active=1').get(dec.id);
    if (!a) return res.status(401).json({ error:'Admin account not found' });
    req.admin = a; next();
  } catch { res.status(401).json({ error:'Invalid or expired admin token.' }); }
};

// ════════════════════════════════════════════════════════════════
// AUTH ROUTES
// ════════════════════════════════════════════════════════════════

// POST /api/auth/register
app.post('/api/auth/register', authLim, [
  body('name').trim().isLength({ min:2 }).withMessage('Name must be at least 2 characters'),
  body('username').trim().isLength({ min:3 }).matches(/^[a-z0-9_.]+$/i).withMessage('Username: min 3 chars, letters/numbers/_ only'),
  body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
  body('phone').matches(/^\d{10}$/).withMessage('Phone must be 10 digits'),
  body('password').isLength({ min:6 }).withMessage('Password must be at least 6 characters'),
  body('confirmPassword').notEmpty(),
], validate, async (req, res) => {
  try {
    const { name, username, email, phone, password, confirmPassword } = req.body;
    if (password !== confirmPassword) return res.status(400).json({ error:'Passwords do not match' });
    if (db.prepare('SELECT id FROM users WHERE username=? OR email=?').get(username,email))
      return res.status(409).json({ error:'Username or email already registered. Please sign in.' });
    const hash  = await bcrypt.hash(password, 12);
    const now   = new Date().toISOString();
    const ins   = db.prepare('INSERT INTO users (name,username,email,phone,password,joined_at) VALUES (?,?,?,?,?,?)');
    const { lastInsertRowid:uid } = ins.run(name.trim(), username.toLowerCase(), email.toLowerCase(), phone, hash, now);
    const user  = db.prepare('SELECT * FROM users WHERE id=?').get(uid);
    const token = mkToken({ id:uid, type:'user' }, JWT_EXP);
    res.status(201).json({ success:true, token, user:safeUser(user) });
  } catch(e) {
    console.error('Register:', e.message);
    res.status(500).json({ error:'Registration failed. Please try again.' });
  }
});

// POST /api/auth/login
app.post('/api/auth/login', authLim, [
  body('identifier').trim().notEmpty().withMessage('Username or email is required'),
  body('password').notEmpty().withMessage('Password is required'),
], validate, async (req, res) => {
  try {
    const { identifier, password } = req.body;
    const id = identifier.toLowerCase().trim();
    const u  = db.prepare('SELECT * FROM users WHERE (username=? OR email=?) AND is_active=1').get(id,id);
    if (!u || !(await bcrypt.compare(password, u.password)))
      return res.status(401).json({ error:'Invalid credentials. Please check username/email and password.' });
    db.prepare('UPDATE users SET last_login=? WHERE id=?').run(new Date().toISOString(), u.id);
    const token = mkToken({ id:u.id, type:'user' }, JWT_EXP);
    res.json({ success:true, token, user:safeUser(u) });
  } catch(e) {
    console.error('Login:', e.message);
    res.status(500).json({ error:'Login failed. Please try again.' });
  }
});

// POST /api/auth/forgot/send
app.post('/api/auth/forgot/send', otpLim, [
  body('email').isEmail().normalizeEmail().withMessage('Invalid email address'),
], validate, async (req, res) => {
  try {
    const { email } = req.body;
    const u = db.prepare('SELECT id,name FROM users WHERE email=? AND is_active=1').get(email.toLowerCase());
    if (!u) return res.status(404).json({ error:'No account found with this email.' });
    const otp = genOTP();
    storeOTP(email, otp, 'forgot');
    const sent = await sendEmail(email, 'Cosfit — Password Reset OTP', emailOTPHtml(u.name, otp));
    res.json({
      success: true,
      message: sent ? 'OTP sent to your email.' : 'OTP generated (email not configured).',
      ...((!IS_PROD || !sent) && { devOtp: otp }),
    });
  } catch(e) {
    console.error('Forgot send:', e.message);
    res.status(500).json({ error:'Failed to send OTP. Please try again.' });
  }
});

// POST /api/auth/forgot/verify
app.post('/api/auth/forgot/verify', [
  body('email').isEmail().normalizeEmail(),
  body('otp').isLength({ min:6, max:6 }).withMessage('OTP must be 6 digits'),
], validate, (req, res) => {
  const { email, otp } = req.body;
  const r = checkOTP(email, otp, 'forgot');
  if (!r.ok) return res.status(400).json({ error:r.msg });
  storeOTP(email, '__VERIFIED__', 'forgot_ok'); // step 2 token
  res.json({ success:true });
});

// POST /api/auth/forgot/reset
app.post('/api/auth/forgot/reset', authLim, [
  body('email').isEmail().normalizeEmail(),
  body('newPassword').isLength({ min:6 }).withMessage('Password must be at least 6 characters'),
  body('confirmPassword').notEmpty(),
], validate, async (req, res) => {
  try {
    const { email, newPassword, confirmPassword } = req.body;
    if (newPassword !== confirmPassword) return res.status(400).json({ error:'Passwords do not match' });
    const r = checkOTP(email, '__VERIFIED__', 'forgot_ok');
    if (!r.ok) return res.status(400).json({ error:'Session expired. Please restart forgot password.' });
    const hash = await bcrypt.hash(newPassword, 12);
    const upd  = db.prepare('UPDATE users SET password=? WHERE email=?').run(hash, email.toLowerCase());
    if (!upd.changes) return res.status(404).json({ error:'User not found' });
    res.json({ success:true, message:'Password updated! Please sign in with your new password.' });
  } catch(e) {
    console.error('Forgot reset:', e.message);
    res.status(500).json({ error:'Failed to reset password. Please try again.' });
  }
});

// ════════════════════════════════════════════════════════════════
// ADMIN AUTH
// ════════════════════════════════════════════════════════════════
app.post('/api/admin/login', authLim, [
  body('username').trim().notEmpty().withMessage('Username required'),
  body('password').notEmpty().withMessage('Password required'),
], validate, async (req, res) => {
  try {
    const { username, password } = req.body;
    const a = db.prepare('SELECT * FROM admins WHERE username=? AND is_active=1').get(username.trim());
    if (!a || !(await bcrypt.compare(password, a.password)))
      return res.status(401).json({ error:'Invalid admin credentials.' });
    const token = mkToken({ id:a.id, type:'admin', role:a.role }, ADM_EXP);
    const { password:_, ...safe } = a;
    res.json({ success:true, token, admin:safe });
  } catch(e) {
    console.error('Admin login:', e.message);
    res.status(500).json({ error:'Admin login failed.' });
  }
});

// ════════════════════════════════════════════════════════════════
// PUBLIC ROUTES
// ════════════════════════════════════════════════════════════════
app.get('/api/menu', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM menu_items ORDER BY goal,meal,id').all();
    res.json({ success:true, foods:menuToFoods(rows), items:rows });
  } catch { res.status(500).json({ error:'Failed to load menu.' }); }
});

app.get('/api/plans', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM plans WHERE is_active=1').all();
    res.json({ success:true, plans:rows.map(p=>({ ...p, features:JSON.parse(p.features), hot:!!p.is_popular })) });
  } catch { res.status(500).json({ error:'Failed to load plans.' }); }
});

app.get('/api/settings/public', (req, res) => {
  try {
    const s = getSettings();
    res.json({ success:true, settings:{ deliveryCharge:+s.delivery_charge, freeDeliveryMin:+s.free_delivery_min, platformFee:+s.platform_fee, gst:+s.gst, appName:s.app_name, tagline:s.tagline, currency:s.currency, supportPhone:s.support_phone, supportEmail:s.support_email } });
  } catch { res.status(500).json({ error:'Failed to load settings.' }); }
});

// ════════════════════════════════════════════════════════════════
// USER ROUTES (protected)
// ════════════════════════════════════════════════════════════════
app.get('/api/user/profile', requireUser, (req, res) => res.json({ success:true, user:safeUser(req.user) }));

app.put('/api/user/profile', requireUser, (req, res) => {
  try {
    const { address, goal, pref, age, weight, height, gender, avatar } = req.body;
    db.prepare('UPDATE users SET address=?,goal=?,pref=?,age=?,weight=?,height=?,gender=?,avatar=? WHERE id=?')
      .run(address||'', goal||'general', pref||'all', String(age||''), String(weight||''), String(height||''), gender||'m', avatar||'😊', req.user.id);
    res.json({ success:true, user:safeUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
  } catch { res.status(500).json({ error:'Failed to update profile.' }); }
});

app.get('/api/orders', requireUser, (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
    res.json({ success:true, orders:rows.map(o=>({...o, items:JSON.parse(o.items)})) });
  } catch { res.status(500).json({ error:'Failed to load orders.' }); }
});

app.post('/api/orders', requireUser, [
  body('items').isArray({ min:1 }).withMessage('Cart is empty'),
  body('total').isNumeric(),
], validate, (req, res) => {
  try {
    const { items, subtotal, delivery, gst, platformFee, total, paymentStatus, userAddress } = req.body;
    const u = req.user;
    const now = Date.now();
    const { lastInsertRowid:oid } = db.prepare(
      'INSERT INTO orders (user_id,user_name,user_username,user_phone,user_address,items,subtotal,delivery,gst,platform_fee,total,status_idx,payment_status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)'
    ).run(u.id, u.name, u.username, u.phone, userAddress||u.address||'', JSON.stringify(items), subtotal, delivery, gst, platformFee, total, paymentStatus||'Cash on Delivery', now, now);
    db.prepare('INSERT INTO notifications (user_id,icon,label,message,created_at) VALUES (?,?,?,?,?)')
      .run(u.id, '✅', 'Order Confirmed', 'Your order is confirmed! We\'re on it.', now);
    const order = db.prepare('SELECT * FROM orders WHERE id=?').get(oid);
    res.status(201).json({ success:true, order:{ ...order, items:JSON.parse(order.items) } });
  } catch(e) {
    console.error('Place order:', e.message);
    res.status(500).json({ error:'Failed to place order. Please try again.' });
  }
});

app.post('/api/plans/activate', requireUser, [body('planId').notEmpty()], validate, (req, res) => {
  try {
    const plan = db.prepare('SELECT * FROM plans WHERE id=? AND is_active=1').get(req.body.planId);
    if (!plan) return res.status(404).json({ error:'Plan not found.' });
    const u = req.user;
    const now = new Date().toISOString();
    db.prepare('INSERT INTO plan_activations (user_id,user_name,user_username,user_phone,plan_id,plan_name,plan_price,plan_per,activated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(u.id, u.name, u.username, u.phone, plan.id, plan.label, plan.price, plan.period, now);
    db.prepare('UPDATE users SET plan=?,plan_name=?,plan_activated_at=? WHERE id=?').run(plan.id, plan.label, now, u.id);
    res.json({ success:true, user:safeUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id)), plan:{ ...plan, features:JSON.parse(plan.features), hot:!!plan.is_popular } });
  } catch { res.status(500).json({ error:'Failed to activate plan.' }); }
});

app.get('/api/notifications', requireUser, (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
    res.json({ success:true, notifications:rows });
  } catch { res.status(500).json({ error:'Failed to load notifications.' }); }
});

app.patch('/api/notifications/read-all', requireUser, (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(req.user.id);
  res.json({ success:true });
});

// ════════════════════════════════════════════════════════════════
// ADMIN ROUTES (protected)
// ════════════════════════════════════════════════════════════════
app.get('/api/admin/orders', requireAdmin, (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
    res.json({ success:true, orders:rows.map(o=>({...o, items:JSON.parse(o.items)})) });
  } catch { res.status(500).json({ error:'Failed to load orders.' }); }
});

app.patch('/api/admin/orders/:id/status', requireAdmin, (req, res) => {
  try {
    const order = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
    if (!order) return res.status(404).json({ error:'Order not found.' });
    if (order.status_idx >= 4) return res.status(400).json({ error:'Order already delivered.' });
    const ns = order.status_idx + 1;
    db.prepare('UPDATE orders SET status_idx=?,updated_at=? WHERE id=?').run(ns, Date.now(), order.id);
    const msgs = [
      { icon:'✅', label:'Order Confirmed',   msg:'Your order is confirmed! We\'re on it.' },
      { icon:'👨‍🍳', label:'Preparing Food',   msg:'Chefs are cooking your fresh meal!' },
      { icon:'📦', label:'Order Packed',      msg:'Packed & ready for pickup.' },
      { icon:'🛵', label:'Out for Delivery',  msg:'Rider is heading to you now!' },
      { icon:'🎉', label:'Delivered!',         msg:'Enjoy your meal! Stay fit 💪' },
    ];
    if (msgs[ns]) db.prepare('INSERT INTO notifications (user_id,icon,label,message,created_at) VALUES (?,?,?,?,?)').run(order.user_id, msgs[ns].icon, msgs[ns].label, msgs[ns].msg, Date.now());
    const updated = db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
    res.json({ success:true, order:{ ...updated, items:JSON.parse(updated.items) } });
  } catch { res.status(500).json({ error:'Failed to update order.' }); }
});

app.get('/api/admin/users',            requireAdmin, (req,res) => { try { res.json({ success:true, users:db.prepare('SELECT id,name,username,email,phone,avatar,plan,plan_name,goal,pref,address,joined_at,last_login,is_active FROM users ORDER BY joined_at DESC').all() }); } catch { res.status(500).json({ error:'Failed.' }); } });
app.get('/api/admin/plan-activations', requireAdmin, (req,res) => { try { res.json({ success:true, activations:db.prepare('SELECT * FROM plan_activations ORDER BY activated_at DESC').all() }); } catch { res.status(500).json({ error:'Failed.' }); } });
app.get('/api/admin/stats',            requireAdmin, (req,res) => {
  try {
    const totalOrders   = db.prepare('SELECT COUNT(*) as c FROM orders').get().c;
    const totalRevenue  = db.prepare('SELECT COALESCE(SUM(total),0) as s FROM orders').get().s;
    const totalUsers    = db.prepare('SELECT COUNT(*) as c FROM users WHERE is_active=1').get().c;
    const activations   = db.prepare('SELECT COUNT(*) as c FROM plan_activations').get().c;
    const liveOrders    = db.prepare('SELECT COUNT(*) as c FROM orders WHERE status_idx<4').get().c;
    const activeItems   = db.prepare('SELECT COUNT(*) as c FROM menu_items WHERE is_active=1 AND in_stock=1').get().c;
    res.json({ success:true, stats:{ totalOrders, totalRevenue, totalUsers, activations, liveOrders, activeItems } });
  } catch { res.status(500).json({ error:'Failed.' }); }
});

app.get('/api/admin/settings', requireAdmin, (req,res) => res.json({ success:true, settings:getSettings() }));
app.put('/api/admin/settings', requireAdmin, (req,res) => {
  try {
    const upd = db.prepare('INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)');
    ['delivery_charge','free_delivery_min','platform_fee','gst'].forEach(k => { if(req.body[k]!==undefined) upd.run(k,String(req.body[k])); });
    res.json({ success:true });
  } catch { res.status(500).json({ error:'Failed to save settings.' }); }
});

app.post('/api/admin/menu', requireAdmin, [body('name').trim().notEmpty(), body('price').isNumeric(), body('goal').isIn(['weight_loss','muscle_gain','general']), body('meal').isIn(['breakfast','lunch','dinner'])], validate, (req,res) => {
  try {
    const { goal,meal,name,description,calories,protein,carbs,fat,price,emoji,tag,prep_time } = req.body;
    const now = Date.now();
    const { lastInsertRowid:id } = db.prepare('INSERT INTO menu_items (goal,meal,name,description,calories,protein,carbs,fat,price,emoji,tag,prep_time,is_active,in_stock,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,1,?,?)').run(goal,meal,name,description,calories||0,protein||0,carbs||0,fat||0,price,emoji||'🍱',tag||'New',prep_time||'15m',now,now);
    res.status(201).json({ success:true, item:db.prepare('SELECT * FROM menu_items WHERE id=?').get(id) });
  } catch { res.status(500).json({ error:'Failed to add item.' }); }
});

app.put('/api/admin/menu/:id', requireAdmin, (req,res) => {
  try {
    const { name,description,calories,protein,carbs,fat,price,emoji,tag,prep_time,is_active,in_stock } = req.body;
    db.prepare('UPDATE menu_items SET name=?,description=?,calories=?,protein=?,carbs=?,fat=?,price=?,emoji=?,tag=?,prep_time=?,is_active=?,in_stock=?,updated_at=? WHERE id=?').run(name,description,calories,protein,carbs,fat,price,emoji,tag,prep_time,is_active?1:0,in_stock?1:0,Date.now(),req.params.id);
    res.json({ success:true, item:db.prepare('SELECT * FROM menu_items WHERE id=?').get(req.params.id) });
  } catch { res.status(500).json({ error:'Failed to update item.' }); }
});

app.delete('/api/admin/menu/:id', requireAdmin, (req,res) => {
  try { db.prepare('DELETE FROM menu_items WHERE id=?').run(req.params.id); res.json({ success:true }); }
  catch { res.status(500).json({ error:'Failed to delete item.' }); }
});

app.post('/api/admin/plans', requireAdmin, (req,res) => {
  try {
    const { id,label,price,period,save_badge,is_popular,color,features } = req.body;
    db.prepare('INSERT OR REPLACE INTO plans (id,label,price,period,save_badge,is_popular,color,features) VALUES (?,?,?,?,?,?,?,?)').run(id||`p${Date.now()}`,label,price,period,save_badge||null,is_popular?1:0,color||'#4ade80',JSON.stringify(features||[]));
    res.status(201).json({ success:true });
  } catch { res.status(500).json({ error:'Failed to save plan.' }); }
});

app.delete('/api/admin/plans/:id', requireAdmin, (req,res) => {
  try { db.prepare('UPDATE plans SET is_active=0 WHERE id=?').run(req.params.id); res.json({ success:true }); }
  catch { res.status(500).json({ error:'Failed to delete plan.' }); }
});

// ════════════════════════════════════════════════════════════════
// HEALTH + FALLBACK
// ════════════════════════════════════════════════════════════════
app.get('/api/health', (req,res) => res.json({ status:'ok', version:'6.0.0', env:NODE_ENV, uptime:process.uptime(), ts:new Date().toISOString() }));
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));

// ── Global Error Handler ───────────────────────────────────────
app.use((err,req,res,next) => {
  console.error('Unhandled error:', err.message);
  res.status(500).json({ error:'Internal server error.' });
});

// ════════════════════════════════════════════════════════════════
// START SERVER
// ════════════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log(`\n🥗 ─────────────────────────────────────────`);
  console.log(`   Cosfit v6.0 — Production Server Started`);
  console.log(`   Port      : ${PORT}`);
  console.log(`   Env       : ${NODE_ENV}`);
  console.log(`   Gmail     : ${GMAIL_USER || '⚠ Not configured (mock mode)'}`);
  console.log(`   Database  : ${DB_PATH}`);
  console.log(`   URL       : http://localhost:${PORT}`);
  console.log(`🥗 ─────────────────────────────────────────\n`);
});

module.exports = app; // for testing
