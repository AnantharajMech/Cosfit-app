# 🥗 Cosfit v6.0 — Production Deployment Guide
> Coscoom Creative Tech Solutions | Complete Setup & Hosting

---

## 📁 Project Structure

```
cosfit-production/
├── server.js          ← Express backend (all APIs)
├── package.json       ← Node.js dependencies
├── .env.example       ← Environment config template
├── cosfit.db          ← SQLite database (auto-created)
├── DEPLOY.md          ← This guide
└── public/
    └── index.html     ← Frontend (same design, API-connected)
```

---

## ⚡ Quick Start (Local)

```bash
# 1. Copy files to your server folder
cd cosfit-production

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.example .env
# Edit .env with your Gmail credentials and JWT secret

# 4. Start server
npm start
# → App running at http://localhost:3000
```

---

## 🔐 Step 1 — Configure .env

Open `.env` and fill in:

```env
PORT=3000
NODE_ENV=production

# Generate this: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_SECRET=your_64_char_random_hex_here

# Gmail App Password Setup:
# Google Account → Security → 2-Step Verification → App Passwords
# Select "Mail" → Generate → Copy the 16-char password
GMAIL_USER=your-gmail@gmail.com
GMAIL_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx

ALLOWED_ORIGIN=https://yourdomain.com
```

---

## 📧 Step 2 — Gmail App Password Setup

1. Go to **myaccount.google.com**
2. Click **Security**
3. Enable **2-Step Verification** (required)
4. Go to **App Passwords**
5. Select **Mail** → **Other** → Type "Cosfit"
6. Click **Generate**
7. Copy the 16-character password
8. Paste into `.env` as `GMAIL_APP_PASSWORD`

> ✅ Real OTPs will be sent to users' Gmail addresses
> ⚠️ Without this, OTP prints to console (dev mode)

---

## 🔑 Admin Login Credentials

| Admin | Username | Password |
|-------|----------|----------|
| Super Admin | Anantharajmech | ananthaarthi160893 |
| Manager | Aarthimech | aarthiananth160893 |
| Staff | Ajithmech | ajithmerga160893 |

> 🔒 Passwords are bcrypt-hashed in database. Never stored as plain text.

---

## 🌐 Step 3 — Deploy to VPS (Ubuntu)

### Install Node.js 18+
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version  # Should show v18+
```

### Install PM2 (Process Manager)
```bash
sudo npm install -g pm2
```

### Upload & Start App
```bash
# Upload files to server (using scp or FileZilla)
scp -r cosfit-production/ user@yourserver:/home/user/cosfit/

# SSH into server
ssh user@yourserver

# Go to app folder
cd /home/user/cosfit

# Install dependencies
npm install --production

# Setup environment
cp .env.example .env
nano .env  # Fill in your values

# Start with PM2
pm2 start server.js --name cosfit
pm2 save
pm2 startup  # Auto-restart on server reboot
```

### Check Status
```bash
pm2 status          # See if running
pm2 logs cosfit     # View logs
pm2 restart cosfit  # Restart app
```

---

## 🔒 Step 4 — Nginx Reverse Proxy + HTTPS

### Install Nginx
```bash
sudo apt install nginx -y
```

### Configure Nginx
```bash
sudo nano /etc/nginx/sites-available/cosfit
```

Paste this config:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/cosfit /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Enable HTTPS (Free SSL)
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
# Follow prompts — enter email, agree to terms
# SSL renews automatically every 90 days
```

---

## 📱 Step 5 — Play Store (PWA)

### Add manifest.json to public/
Create `public/manifest.json`:
```json
{
  "name": "Cosfit — Eat Smart Live Strong",
  "short_name": "Cosfit",
  "description": "Smart fitness food delivery",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#060c08",
  "theme_color": "#4ade80",
  "orientation": "portrait",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

### Add Service Worker (public/sw.js)
```javascript
const CACHE = 'cosfit-v6';
const ASSETS = ['/', '/index.html'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});
```

### Convert PWA to Play Store APK

**Option A — Bubblewrap (Google's tool)**
```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://yourdomain.com/manifest.json
bubblewrap build
# Generates signed APK for Play Store
```

**Option B — PWABuilder (Easier)**
1. Visit **pwabuilder.com**
2. Enter your app URL
3. Click **Package for Stores**
4. Download Android package
5. Upload to Google Play Console

---

## 🗄️ Database Backup

### Manual Backup
```bash
# Copy the SQLite database file
cp /home/user/cosfit/cosfit.db /backup/cosfit_$(date +%Y%m%d).db
```

### Automated Daily Backup (Cron)
```bash
crontab -e
# Add this line:
0 2 * * * cp /home/user/cosfit/cosfit.db /backup/cosfit_$(date +\%Y\%m\%d).db
```

---

## 📊 API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login with username/email + password |
| POST | /api/auth/forgot/send | Send OTP to Gmail |
| POST | /api/auth/forgot/verify | Verify OTP |
| POST | /api/auth/forgot/reset | Set new password |
| POST | /api/admin/login | Admin login |

### User (requires Bearer token)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/user/profile | Get user profile |
| PUT | /api/user/profile | Update profile |
| GET | /api/orders | User's orders |
| POST | /api/orders | Place new order |
| POST | /api/plans/activate | Activate a plan |
| GET | /api/notifications | Get notifications |

### Public
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/menu | All menu items |
| GET | /api/plans | All plans |
| GET | /api/settings/public | App settings |
| GET | /api/health | Server health check |

### Admin (requires Admin Bearer token)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/admin/orders | All orders |
| PATCH | /api/admin/orders/:id/status | Update order status |
| GET | /api/admin/users | All customers |
| GET | /api/admin/stats | Dashboard stats |
| GET/PUT | /api/admin/settings | App settings |
| POST/PUT/DELETE | /api/admin/menu | Manage menu |
| POST/DELETE | /api/admin/plans | Manage plans |

---

## 🔧 Troubleshooting

**App not starting?**
```bash
pm2 logs cosfit --lines 50
# Check for missing .env values
```

**Gmail OTP not sending?**
```bash
# Verify credentials in .env
# Make sure 2FA is enabled on Gmail
# Check if App Password is 16 chars (no spaces)
# Server shows "Mock Email" if Gmail not configured
```

**Port 3000 already in use?**
```bash
# Change PORT in .env to 4000 or any free port
# Update Nginx proxy_pass accordingly
```

**Database locked error?**
```bash
# Restart the app
pm2 restart cosfit
```

---

## 🚀 Production Checklist

- [ ] `.env` configured with real values
- [ ] Gmail App Password set up and tested
- [ ] JWT_SECRET is a long random string (64+ chars)
- [ ] NODE_ENV=production in .env
- [ ] PM2 running and saved
- [ ] Nginx configured and active
- [ ] SSL certificate installed (HTTPS)
- [ ] Domain pointing to server IP
- [ ] Daily backup cron job set up
- [ ] manifest.json added for PWA
- [ ] sw.js added for offline support
- [ ] Icons added (icon-192.png, icon-512.png)

---

## 📞 Support

**Company:** Coscoom Creative Tech Solutions  
**Brand:** Idappadi Creators  
**Email:** anantharajeinstein@gmail.com  
**Phone:** 8778148899  
**Address:** 21/AJ, 68, New Street, Kavandampatti, Idappadi, Salem - 637101, Tamilnadu

---

*Cosfit v6.0 — Built for production. Eat Smart · Live Strong* 🥗
